#using range
#syntax range(start,stop,step)
#note stop is NOT inclusive!

for num in range(10):
    print(num)